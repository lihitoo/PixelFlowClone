using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using Dreamy.Datasave;
using NUnit.Framework;
using PixelFlow.Rules;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.InputSystem.UI;
using UnityEngine.EventSystems;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace PixelFlow.EditorReview
{
    // These are Editor fixtures. EnterPlayMode exercises the actual scene without
    // building a player. Offscreen captures explicitly change canvas render mode;
    // they are layout previews, not Game View, device or original-game evidence.
    public sealed class PresentationReviewTests
    {
        [SerializeField] private string previousScope;
        [SerializeField] private string scope;
        private Mouse pointer;
        private readonly List<InputDevice> suspendedDevices = new();
        private InputSettings previousInputSettings, ownedInputSettings;
        private PixelFlowApp app;
        private readonly List<string> checks = new();
        private string folder;

        [SetUp]
        public void PrepareScene()
        {
            // EnterPlayMode/ExitPlayMode reload the domain and replay NUnit setup.
            // SessionState survives that transition; never reopen/reset a live scene.
            if (SessionState.GetBool("PixelFlow.Review.Prepared", false))
            {
                scope = SessionState.GetString("PixelFlow.Review.Scope", "");
                previousScope = SessionState.GetString("PixelFlow.Review.PreviousScope", "");
                return;
            }
            Assert.That(Application.isPlaying, Is.False);
            previousScope = Environment.GetEnvironmentVariable("PIXEL_FLOW_EDITOR_SAVE_SCOPE");
            scope = "Review_" + Guid.NewGuid().ToString("N");
            SessionState.SetBool("PixelFlow.Review.Prepared", true);
            SessionState.SetString("PixelFlow.Review.Scope", scope);
            SessionState.SetString("PixelFlow.Review.PreviousScope", previousScope ?? "");
            Environment.SetEnvironmentVariable("PIXEL_FLOW_EDITOR_SAVE_SCOPE", scope);
            EditorSceneManager.OpenScene("Assets/_Project/PixelFlow/Scenes/PixelFlow.unity");
        }

        private IEnumerator Ready()
        {
            Assert.That(SystemInfo.graphicsDeviceType, Is.Not.EqualTo(GraphicsDeviceType.Null), "Editor review requires a graphics device; -nographics cannot verify rendered pixels.");
            float deadline = Time.realtimeSinceStartup + 30;
            while (Time.realtimeSinceStartup < deadline)
            {
                app = Object.FindFirstObjectByType<PixelFlowApp>();
                if (app != null && app.ScreenState == AppScreen.Home) break;
                yield return null;
            }
            Assert.That(app, Is.Not.Null, "Scene bootstrap exists");
            Assert.That(app.ScreenState, Is.EqualTo(AppScreen.Home), "Scene reaches Home");
            Assert.That(app.SaveDirectory, Is.EqualTo("PixelFlowCloneSmoke_" + scope), "Never touch the owner's normal save");
            Assert.That(app.Progress.Data.UnlockedLevel, Is.Zero, "Fixture starts with a fresh save");
            string run = Environment.GetEnvironmentVariable("PIXEL_FLOW_REVIEW_RUN") ?? "editor-review";
            Assert.That(System.Text.RegularExpressions.Regex.IsMatch(run, "^[A-Za-z0-9_-]{1,64}$"), Is.True);
            folder = Path.GetFullPath(Path.Combine(Application.dataPath, "../Docs/Evidence/editor-review", run));
            Directory.CreateDirectory(folder);
            previousInputSettings = InputSystem.settings;
            ownedInputSettings = Object.Instantiate(previousInputSettings);
            ownedInputSettings.editorInputBehaviorInPlayMode = InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
            // InputSystemUIInputModule otherwise discards pointer state while a
            // batch Editor has no focused Game View. Change only the owned clone.
            ownedInputSettings.backgroundBehavior = InputSettings.BackgroundBehavior.IgnoreFocus;
            // EditMode's EnterPlayMode runner does not pump the queued device
            // events like a normally launched player. Own and pump them explicitly.
            ownedInputSettings.updateMode = InputSettings.UpdateMode.ProcessEventsManually;
            InputSystem.settings = ownedInputSettings;
            // Desktop input must not move the UI pointer or trigger Escape while
            // a fixture runs. This affects only this batch Editor's Input System,
            // never OS devices; restore every device below.
            foreach (var device in InputSystem.devices)
                if (device.enabled)
                {
                    InputSystem.DisableDevice(device);
                    suspendedDevices.Add(device);
                }
            pointer = InputSystem.AddDevice<Mouse>("PixelFlowEditorReviewPointer");
            checks.Clear();
            checks.Add("Actual scene bootstrap reaches Home using an isolated fresh save");
            yield return null;
        }

        private IEnumerator Click(Vector2 position)
        {
            EnsureBatchUiRendered();
            InputSystem.QueueStateEvent(pointer, new MouseState { position = position }.WithButton(MouseButton.Left));
            InputSystem.Update();
            EventSystem.current.currentInputModule.Process();
            yield return null;
            yield return null;
            InputSystem.QueueStateEvent(pointer, new MouseState { position = position });
            InputSystem.Update();
            EventSystem.current.currentInputModule.Process();
            yield return null;
            yield return null;
        }

        private IEnumerator Click(Button button)
        {
            // A render-preview capture temporarily changes root-canvas geometry.
            // Let the normal overlay layout settle before deriving pointer coords.
            yield return null;
            yield return null;
            Canvas.ForceUpdateCanvases();
            var point = RectTransformUtility.WorldToScreenPoint(null, button.transform.position);
            bool invoked = false;
            UnityEngine.Events.UnityAction observe = () => invoked = true;
            button.onClick.AddListener(observe);
            yield return Click(point);
            button.onClick.RemoveListener(observe);
            if (!invoked)
            {
                var system = EventSystem.current;
                var hits = new List<RaycastResult>();
                system.RaycastAll(new PointerEventData(system) { position = point }, hits);
                var module = system.GetComponent<InputSystemUIInputModule>();
                Debug.Log("[PixelFlowReviewInput] button=" + button.name + " screen=" + Screen.width + "x" + Screen.height + " frame=" + Time.frameCount +
                    " requested=" + point + " mouse=" + pointer.position.ReadValue() + " focused=" + system.isFocused +
                    " module=" + system.currentInputModule + " pointEnabled=" + module.point.action.enabled +
                    " clickEnabled=" + module.leftClick.action.enabled + " actionPoint=" + module.point.action.ReadValue<Vector2>() +
                    " hits=" + string.Join(",", hits.ConvertAll(hit => hit.gameObject.name)) +
                    " app=" + app.ScreenState + " buttonActive=" + button.gameObject.activeInHierarchy +
                    " pointerAdded=" + pointer.added + " pointerEnabled=" + pointer.enabled +
                    " settings=" + InputSystem.settings.name + " mode=" + InputSystem.settings.updateMode +
                    " apps=" + Object.FindObjectsByType<PixelFlowApp>(FindObjectsSortMode.None).Length +
                    " depth=" + button.image.depth + " culled=" + button.image.canvasRenderer.cull);
            }
        }

        private IEnumerator ClickPig(int id)
        {
            yield return Click(app.WorldCamera.WorldToScreenPoint(app.Board.PigPosition(id) + Vector3.up * .55f));
        }

        [UnityTest, Timeout(180000)]
        public IEnumerator CaptureRepresentativeStates()
        {
            yield return new EnterPlayMode();
            yield return Ready();
            CaptureAspects("home");
            yield return Click(app.View.PlayButton);
            Assert.That(app.ScreenState, Is.EqualTo(AppScreen.Playing));
            yield return null;
            CaptureAspects("level-1");
            yield return Click(app.View.PauseButton);
            Assert.That(app.ScreenState, Is.EqualTo(AppScreen.Paused));
            Capture("pause", 720, 1280);
            WriteEvidence("captures", "Scene Home/Play/Pause reached through queued pointer input; offscreen layout previews at three portrait aspects.");
            RestoreInput();
            yield return new ExitPlayMode();
        }

        [UnityTest, Timeout(240000)]
        public IEnumerator PointerInputResetAndProgressionRoute()
        {
            yield return new EnterPlayMode();
            yield return Ready();
            yield return Click(app.View.PlayButton);
            Assert.That(app.ScreenState, Is.EqualTo(AppScreen.Playing));
            var first = app.Session;
            yield return ClickPig(first.QueueAt(0, 1).Id);
            Assert.That(first.Launches, Is.Zero, "Rear queue pig is unavailable");
            checks.Add("Pointer click on rear queue pig cannot launch it");

            yield return Click(app.View.PauseButton);
            int pixels = first.RemainingPixels;
            yield return ClickPig(first.QueueAt(0).Id);
            yield return new WaitForSecondsRealtime(.15f);
            Assert.That(app.ScreenState, Is.EqualTo(AppScreen.Paused));
            Assert.That(first.Launches, Is.Zero, "Pause modal blocks world pointer clicks");
            Assert.That(first.RemainingPixels, Is.EqualTo(pixels));
            bool sound = app.Progress.Data.SoundEnabled;
            yield return Click(app.View.SoundButton);
            Assert.That(app.Progress.Data.SoundEnabled, Is.EqualTo(!sound));
            yield return Click(app.View.SoundButton);
            Assert.That(app.Progress.Data.SoundEnabled, Is.EqualTo(sound));
            yield return Click(app.View.ResumeButton);
            checks.Add("Pause freezes puzzle, blocks world click-through and permits sound/resume controls");

            int selected = first.QueueAt(0).Id;
            yield return ClickPig(selected);
            Assert.That(first.Launches, Is.EqualTo(1));
            yield return ClickPig(selected);
            Assert.That(first.Launches, Is.EqualTo(1), "Clicking the same moving pig does not duplicate it");
            checks.Add("Repeated pointer selection of a moving pig cannot duplicate launch");
            for (int i = 0; i < 4; i++)
            {
                ShooterState candidate = null;
                for (int column = 0; column < first.ColumnCount && candidate == null; column++) candidate = first.QueueAt(column);
                Assert.That(candidate, Is.Not.Null);
                yield return ClickPig(candidate.Id);
            }
            Assert.That(first.Active.Count, Is.EqualTo(first.Level.ConveyorLimit));
            ShooterState remaining = null;
            for (int column = 0; column < first.ColumnCount && remaining == null; column++) remaining = first.QueueAt(column);
            Assert.That(remaining, Is.Not.Null);
            int launches = first.Launches, ammo = remaining.Ammo;
            yield return ClickPig(remaining.Id);
            Assert.That(first.Launches, Is.EqualTo(launches));
            Assert.That(remaining.Location, Is.EqualTo(ShooterLocation.Queue));
            Assert.That(remaining.Ammo, Is.EqualTo(ammo));
            checks.Add("Full-belt pointer rejection preserves queue membership and ammunition");
            yield return Click(app.View.PauseButton);
            Capture("full-belt-paused", 720, 1280);

            var oldPig = app.Board.Pig(selected);
            // Invoke the actual button event synchronously for this same-frame
            // lifecycle assertion; other route actions above/below use pointer input.
            app.View.RestartButton.onClick.Invoke();
            Assert.That(oldPig.gameObject.activeInHierarchy, Is.False, "Retired board is inactive before deferred Destroy runs");
            Assert.That(app.Session, Is.Not.SameAs(first));
            Assert.That(app.Session.Launches, Is.Zero);
            Assert.That(app.Session.RemainingPixels, Is.EqualTo(180));
            yield return null;
            checks.Add("Same-frame Restart button event disables retired board before deferred destruction and resets the session");

            float deadline = Time.realtimeSinceStartup + 150;
            bool waiting = false;
            while (app.ScreenState == AppScreen.Playing && Time.realtimeSinceStartup < deadline)
            {
                foreach (var pig in app.Session.Waiting) if (pig != null) waiting = true;
                int candidate = PixelFlowSmoke.Choose(app.Session);
                if (candidate >= 0 && app.Session.Active.Count < app.Session.Level.ConveyorLimit)
                {
                    yield return new WaitForSecondsRealtime(.20f);
                    if (app.Session.CanSelect(candidate)) yield return ClickPig(candidate);
                }
                else yield return null;
            }
            Assert.That(app.ScreenState, Is.EqualTo(AppScreen.Won), app.Session?.LossReason);
            Assert.That(waiting, Is.True, "Actual route includes a return to waiting");
            var reload = new DatasaveService(new DatasaveOptions { DirectoryName = app.SaveDirectory });
            var saved = reload.Load<PixelFlowProgress>(PixelFlowProgress.Key);
            Assert.That(saved.CompletedLevels, Does.Contain(0));
            Assert.That(saved.UnlockedLevel, Is.EqualTo(1));
            checks.Add("Pointer-driven source level1 wins, includes waiting return and persists completion/unlock");
            Capture("win", 720, 1280);
            yield return Click(app.View.NextButton);
            Assert.That(app.SelectedLevel, Is.EqualTo(1));
            Assert.That(app.Session.RemainingPixels, Is.EqualTo(400));
            yield return Click(app.View.PauseButton);
            yield return Click(app.View.RestartButton);
            Assert.That(app.ScreenState, Is.EqualTo(AppScreen.Playing), "Pointer Retry actually leaves the pause modal");
            Assert.That(app.Session.Launches, Is.Zero);
            Assert.That(app.Session.RemainingPixels, Is.EqualTo(400));
            yield return Click(app.View.PauseButton);
            var voices = app.GetComponentsInChildren<AudioSource>();
            Assert.That(voices.Length, Is.GreaterThan(0));
            voices[0].loop = true;
            voices[0].Play(); // Deliberate ongoing-session sound for cleanup regression.
            yield return Click(app.View.MenuButton);
            Assert.That(app.ScreenState, Is.EqualTo(AppScreen.Home));
            foreach (var voice in voices) Assert.That(voice.isPlaying, Is.False, "Home clears ongoing session audio");
            voices[0].loop = false;
            Capture("home-progress", 720, 1280);
            checks.Add("Next and pointer Retry rebuild source level2; Home clears session and ongoing audio");
            for (int i = 0; i < 3; i++)
            {
                yield return Click(app.View.PlayButton);
                Assert.That(app.Session.Launches, Is.Zero);
                yield return Click(app.View.PauseButton);
                yield return Click(app.View.MenuButton);
                Assert.That(Object.FindObjectsByType<PigView>(FindObjectsSortMode.None), Is.Empty);
            }
            checks.Add("Three repeated Home/Play cycles leave no active stale pig objects");
            WriteEvidence("route", "Actual Editor scene with queued Input System mouse input; synchronous Restart event is explicitly labeled. No player build, device, listening, performance or original-game fidelity acceptance.");
            RestoreInput();
            yield return new ExitPlayMode();
        }

        private void CaptureAspects(string state)
        {
            Capture(state, 720, 1280);
            Capture(state, 1080, 1920);
            Capture(state, 1080, 2340);
        }

        private void EnsureBatchUiRendered()
        {
            // A batch Editor has no drawing Game View. Re-enabled modal graphics
            // can retain depth=-1, which GraphicRaycaster correctly excludes.
            // Render the actual owned canvas rather than bypassing its raycaster.
            Canvas.ForceUpdateCanvases();
            var canvas = app.View.PlayButton.GetComponentInParent<Canvas>();
            foreach (var graphic in canvas.GetComponentsInChildren<Graphic>())
                if (graphic.raycastTarget && (graphic.depth < 0 || graphic.canvasRenderer.cull))
                {
                    Capture("ui-warmup", Screen.width, Screen.height, false);
                    break;
                }
        }

        private void Capture(string state, int width, int height, bool writeFile = true)
        {
            var camera = app.WorldCamera;
            var canvas = app.View.PlayButton.GetComponentInParent<Canvas>();
            var previousMode = canvas.renderMode;
            var previousCamera = canvas.worldCamera;
            float previousPlane = canvas.planeDistance, previousAspect = camera.aspect, previousSize = camera.orthographicSize;
            var previousTarget = camera.targetTexture;
            var previousActive = RenderTexture.active;
            bool previousAsync = ShaderUtil.allowAsyncCompilation;
            var target = new RenderTexture(width, height, 24, RenderTextureFormat.ARGB32);
            var pixels = new Texture2D(width, height, TextureFormat.RGB24, false);
            try
            {
                target.Create();
                ShaderUtil.allowAsyncCompilation = false;
                camera.targetTexture = target;
                camera.aspect = (float)width / height;
                camera.orthographicSize = Mathf.Max(8.4f, 4.55f / camera.aspect);
                canvas.renderMode = RenderMode.ScreenSpaceCamera;
                canvas.worldCamera = camera;
                canvas.planeDistance = .5f;
                Canvas.ForceUpdateCanvases();
                if (app.Session != null) app.View.UpdateGame(app.Session, camera);
                RenderPipeline.SubmitRenderRequest(camera, new UniversalRenderPipeline.SingleCameraRequest { destination = target });
                if (writeFile)
                {
                    RenderTexture.active = target;
                    pixels.ReadPixels(new Rect(0, 0, width, height), 0, 0);
                    pixels.Apply();
                    byte[] png = pixels.EncodeToPNG();
                    Assert.That(png.Length, Is.GreaterThan(1000), "Preview contains rendered pixels");
                    string path = Path.Combine(folder, state + "-" + width + "x" + height + ".png");
                    if (File.Exists(path)) throw new IOException("Review evidence already exists; select a fresh PIXEL_FLOW_REVIEW_RUN: " + path);
                    File.WriteAllBytes(path, png);
                }
            }
            finally
            {
                RenderTexture.active = previousActive;
                ShaderUtil.allowAsyncCompilation = previousAsync;
                canvas.renderMode = previousMode;
                canvas.worldCamera = previousCamera;
                canvas.planeDistance = previousPlane;
                camera.targetTexture = previousTarget;
                camera.aspect = previousAspect;
                camera.orthographicSize = previousSize;
                Canvas.ForceUpdateCanvases();
                if (app.Session != null) app.View.UpdateGame(app.Session, camera);
                target.Release(); Object.Destroy(target); Object.Destroy(pixels);
            }
        }

        private void WriteEvidence(string name, string scopeDescription)
        {
            File.WriteAllText(Path.Combine(folder, name + ".json"), JsonUtility.ToJson(new Evidence
            {
                status = "pass", unity = Application.unityVersion, scope = scopeDescription,
                saveDirectory = app.SaveDirectory, checks = checks.ToArray(),
                captureMethod = "Offscreen URP camera request, temporarily converting the owned overlay canvas to ScreenSpaceCamera; full-rect preview, not simulated device safe area or Game View capture.",
                inputMethod = "Queued synthetic MouseState events with explicit InputSystem.Update and active EventSystem module Process, isolated devices/settings, and an offscreen UI warmup when graphics have no raycast depth in batchmode; UI/Physics processing, not physical-device input or normal frame scheduling proof."
            }, true));
        }

        [UnityTearDown]
        public IEnumerator Cleanup()
        {
            RestoreInput();
            if (Application.isPlaying) yield return new ExitPlayMode();
            Environment.SetEnvironmentVariable("PIXEL_FLOW_EDITOR_SAVE_SCOPE", string.IsNullOrEmpty(previousScope) ? null : previousScope);
            SessionState.EraseBool("PixelFlow.Review.Prepared");
            SessionState.EraseString("PixelFlow.Review.Scope");
            SessionState.EraseString("PixelFlow.Review.PreviousScope");
        }

        private void RestoreInput()
        {
            if (pointer != null && pointer.added) InputSystem.RemoveDevice(pointer);
            pointer = null;
            foreach (var device in suspendedDevices)
                if (device.added && !device.enabled) InputSystem.EnableDevice(device);
            suspendedDevices.Clear();
            if (ownedInputSettings != null)
            {
                InputSystem.settings = previousInputSettings;
                Object.Destroy(ownedInputSettings);
                ownedInputSettings = null;
            }
        }

        [Serializable]
        private sealed class Evidence
        {
            public string status, unity, scope, saveDirectory, captureMethod, inputMethod;
            public string[] checks;
        }
    }
}
