using System;
using System.Collections.Generic;

namespace PixelFlow.Rules
{
    [Serializable]
    public sealed class LevelDefinition
    {
        public int SourceNumber;
        public string Title;
        public int Width;
        public int Height;
        public int SlotCount = 5;
        public int ConveyorLimit = 5;
        public List<PixelDefinition> Pixels = new();
        public List<QueueDefinition> Queues = new();

        public void Validate()
        {
            if (Width < 1 || Height < 1 || Width > 128 || Height > 128)
                throw new ArgumentException("Board dimensions must be 1..128.");
            if (SlotCount < 1 || SlotCount > 8 || ConveyorLimit < 1 || ConveyorLimit > 8)
                throw new ArgumentException("Slot and conveyor capacities must be 1..8.");
            if (Pixels == null || Pixels.Count == 0 || Queues == null || Queues.Count < 1 || Queues.Count > 5)
                throw new ArgumentException("A level needs pixels and 1..5 shooter queues.");
            var positions = new HashSet<int>();
            var colors = new Dictionary<int, int>();
            foreach (var pixel in Pixels)
            {
                if (pixel == null || pixel.X < 0 || pixel.X >= Width || pixel.Y < 0 || pixel.Y >= Height || pixel.Color < 0)
                    throw new ArgumentException("Pixel outside the board or invalid color.");
                if (!positions.Add(pixel.Y * Width + pixel.X)) throw new ArgumentException("Duplicate pixel coordinate.");
                colors[pixel.Color] = colors.GetValueOrDefault(pixel.Color) + 1;
            }
            var ids = new HashSet<int>();
            var ammo = new Dictionary<int, int>();
            foreach (var queue in Queues)
            {
                if (queue?.Shooters == null) throw new ArgumentException("Missing shooter queue.");
                foreach (var shooter in queue.Shooters)
                {
                    if (shooter == null || !ids.Add(shooter.Id) || shooter.Ammo < 1 || shooter.Color < 0)
                        throw new ArgumentException("Invalid or duplicate shooter.");
                    ammo[shooter.Color] = ammo.GetValueOrDefault(shooter.Color) + shooter.Ammo;
                }
            }
            foreach (var pair in colors)
                if (ammo.GetValueOrDefault(pair.Key) < pair.Value)
                    throw new ArgumentException("Insufficient ammunition for a board color.");
        }
    }

    [Serializable] public sealed class PixelDefinition { public int X; public int Y; public int Color; }
    [Serializable] public sealed class ShooterDefinition { public int Id; public int Ammo; public int Color; }
    [Serializable] public sealed class QueueDefinition { public List<ShooterDefinition> Shooters = new(); }
}
