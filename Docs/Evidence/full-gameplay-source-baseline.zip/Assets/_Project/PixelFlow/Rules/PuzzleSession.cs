using System;
using System.Collections.Generic;

namespace PixelFlow.Rules
{
    public enum SessionStatus { Playing, Won, Lost }
    public enum ShooterLocation { Queue, Conveyor, Waiting, Finished }
    public enum LaunchResult { Accepted, ConveyorFull, Unavailable, SessionFinished }

    public sealed class ShooterState
    {
        public int Id { get; internal set; }
        public int Color { get; internal set; }
        public int Ammo { get; internal set; }
        public int Column { get; internal set; }
        public ShooterLocation Location { get; internal set; }
        public float Progress { get; internal set; }
        internal float ShotTimer;
    }

    public readonly struct ShotRecord
    {
        public readonly int ShooterId, X, Y, Color;
        public ShotRecord(int shooterId, int x, int y, int color) { ShooterId = shooterId; X = x; Y = y; Color = color; }
    }

    public sealed class PuzzleSession
    {
        private const float StepSeconds = .01f;
        private readonly List<ShooterState>[] queues;
        private readonly int[] fronts;
        private readonly List<ShooterState> active = new();
        private readonly ShooterState[] waiting;
        private readonly Dictionary<int, ShooterState> shooters = new();
        private readonly int[] pixels;
        private readonly float loopSeconds, shotInterval;
        private double accumulator;

        public LevelDefinition Level { get; }
        public TrackGeometry Track { get; }
        public SessionStatus Status { get; private set; } = SessionStatus.Playing;
        public string LossReason { get; private set; }
        public int RemainingPixels { get; private set; }
        public int InitialPixels { get; }
        public int Launches { get; private set; }
        public IReadOnlyList<ShooterState> Active => active;
        public IReadOnlyList<ShooterState> Waiting => waiting;
        public IReadOnlyDictionary<int, ShooterState> Shooters => shooters;
        public int ColumnCount => queues.Length;
        public event Action<ShotRecord> Shot;
        public event Action<SessionStatus> Finished;

        public PuzzleSession(LevelDefinition level, float loopSeconds = 8.8f, float shotInterval = .045f)
        {
            level.Validate();
            if (!float.IsFinite(loopSeconds) || !float.IsFinite(shotInterval) || loopSeconds <= 0 || shotInterval <= 0)
                throw new ArgumentOutOfRangeException(nameof(loopSeconds));
            Level = level; Track = new TrackGeometry(level.Width, level.Height);
            this.loopSeconds = loopSeconds; this.shotInterval = shotInterval;
            pixels = new int[level.Width * level.Height]; Array.Fill(pixels, -1);
            foreach (var pixel in level.Pixels) pixels[pixel.Y * level.Width + pixel.X] = pixel.Color;
            InitialPixels = RemainingPixels = level.Pixels.Count;
            waiting = new ShooterState[level.SlotCount];
            queues = new List<ShooterState>[level.Queues.Count]; fronts = new int[queues.Length];
            for (int column = 0; column < queues.Length; column++)
            {
                queues[column] = new List<ShooterState>();
                foreach (var source in level.Queues[column].Shooters)
                {
                    var shooter = new ShooterState { Id = source.Id, Color = source.Color, Ammo = source.Ammo, Column = column, Location = ShooterLocation.Queue };
                    shooters.Add(shooter.Id, shooter); queues[column].Add(shooter);
                }
            }
        }

        public int PixelAt(int x, int y) => pixels[y * Level.Width + x];
        public int QueueCount(int column) => queues[column].Count - fronts[column];
        public ShooterState QueueAt(int column, int offset = 0)
        {
            int index = fronts[column] + offset;
            return index < queues[column].Count ? queues[column][index] : null;
        }

        public bool CanSelect(int id)
        {
            if (!shooters.TryGetValue(id, out var shooter)) return false;
            return shooter.Location == ShooterLocation.Waiting ||
                   (shooter.Location == ShooterLocation.Queue && QueueAt(shooter.Column) == shooter);
        }

        public LaunchResult Launch(int id)
        {
            if (Status != SessionStatus.Playing) return LaunchResult.SessionFinished;
            if (!CanSelect(id)) return LaunchResult.Unavailable;
            if (active.Count >= Level.ConveyorLimit) return LaunchResult.ConveyorFull;
            var shooter = shooters[id];
            if (shooter.Location == ShooterLocation.Queue) fronts[shooter.Column]++;
            else waiting[Array.IndexOf(waiting, shooter)] = null;
            shooter.Location = ShooterLocation.Conveyor;
            // Preserve launch order and avoid stacking rapid taps at the same entrance.
            float entry = 0;
            foreach (var other in active) if (other.Progress < .07f) entry = Math.Min(entry, other.Progress - .07f);
            shooter.Progress = entry; shooter.ShotTimer = 0;
            active.Add(shooter); Launches++;
            return LaunchResult.Accepted;
        }

        public void Tick(float deltaSeconds)
        {
            if (!float.IsFinite(deltaSeconds) || deltaSeconds < 0 || deltaSeconds > 60)
                throw new ArgumentOutOfRangeException(nameof(deltaSeconds));
            if (Status != SessionStatus.Playing) return;
            accumulator += deltaSeconds;
            while (accumulator + 1e-8 >= StepSeconds && Status == SessionStatus.Playing)
            {
                accumulator -= StepSeconds;
                Step();
            }
        }

        private void Step()
        {
            for (int index = 0; index < active.Count && Status == SessionStatus.Playing;)
            {
                var shooter = active[index];
                shooter.Progress += StepSeconds / loopSeconds;
                if (shooter.Progress >= 0) shooter.ShotTimer -= StepSeconds;
                if (shooter.Progress >= 0 && shooter.ShotTimer <= 0)
                {
                    shooter.ShotTimer += shotInterval;
                    var point = Track.At(Math.Min(shooter.Progress, .999999f));
                    if (point.Lane >= 0) TryHit(shooter, point.Side, point.Lane);
                }
                if (Status != SessionStatus.Playing) return;
                if (shooter.Ammo == 0)
                {
                    shooter.Location = ShooterLocation.Finished; active.RemoveAt(index);
                }
                else if (shooter.Progress >= 1)
                {
                    int slot = Array.IndexOf(waiting, null);
                    if (slot < 0) { Finish(SessionStatus.Lost, "The waiting area is full."); return; }
                    shooter.Location = ShooterLocation.Waiting; waiting[slot] = shooter; active.RemoveAt(index);
                }
                else index++;
            }
            if (active.Count == 0)
            {
                bool available = false;
                foreach (var shooter in shooters.Values)
                    if (shooter.Location != ShooterLocation.Finished && shooter.Ammo > 0) { available = true; break; }
                if (!available && RemainingPixels > 0) Finish(SessionStatus.Lost, "No ammunition remains.");
            }
        }

        private bool TryHit(ShooterState shooter, BoardSide side, int lane)
        {
            int count = side is BoardSide.Left or BoardSide.Right ? Level.Width : Level.Height;
            for (int depth = 0; depth < count; depth++)
            {
                int x = side switch { BoardSide.Left => depth, BoardSide.Right => Level.Width - depth - 1, _ => lane };
                int y = side switch { BoardSide.Bottom => depth, BoardSide.Top => Level.Height - depth - 1, _ => lane };
                int offset = y * Level.Width + x;
                if (pixels[offset] < 0) continue;
                if (pixels[offset] != shooter.Color) return false;
                pixels[offset] = -1; shooter.Ammo--; RemainingPixels--;
                Shot?.Invoke(new ShotRecord(shooter.Id, x, y, shooter.Color));
                if (RemainingPixels == 0) Finish(SessionStatus.Won);
                return true;
            }
            return false;
        }

        private void Finish(SessionStatus status, string reason = null)
        {
            if (Status != SessionStatus.Playing) return;
            Status = status; LossReason = reason; Finished?.Invoke(status);
        }
    }
}
