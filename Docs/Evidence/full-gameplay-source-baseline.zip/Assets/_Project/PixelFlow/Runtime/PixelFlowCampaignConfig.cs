using System;
using System.Collections.Generic;
using Dreamy.DataConfig;
using PixelFlow.Rules;
using UnityEngine;

namespace PixelFlow
{
    [Serializable]
    public sealed class PixelFlowCampaignConfig : ConfigBase
    {
        public float LoopSeconds = 8.8f;
        public float ShotInterval = .045f;
        public List<PaletteEntry> Colors = new();
        public List<LevelDefinition> Levels = new();

        public override void Initialize(string documentName)
        {
            if (Levels == null || Levels.Count == 0 || Colors == null || Colors.Count == 0)
                throw new ArgumentException("Campaign needs levels and a palette.");
            if (LoopSeconds <= 0 || ShotInterval <= 0) throw new ArgumentException("Invalid shot/belt timing.");
            var ids = new HashSet<int>();
            foreach (var entry in Colors)
                if (entry == null || !ids.Add(entry.Id)) throw new ArgumentException("Invalid palette.");
            foreach (var level in Levels)
            {
                level.Validate();
                foreach (var pixel in level.Pixels)
                    if (!ids.Contains(pixel.Color)) throw new ArgumentException("Pixel references a missing color.");
                foreach (var queue in level.Queues)
                    foreach (var shooter in queue.Shooters)
                        if (!ids.Contains(shooter.Color)) throw new ArgumentException("Shooter references a missing color.");
            }
        }

        public Color ColorFor(int id)
        {
            foreach (var entry in Colors) if (entry.Id == id) return new Color(entry.R, entry.G, entry.B);
            throw new ArgumentOutOfRangeException(nameof(id));
        }
    }

    [Serializable] public sealed class PaletteEntry { public int Id; public string Name; public float R, G, B; }
}
