using System;
using System.Collections.Generic;
using Dreamy.Datasave;

namespace PixelFlow
{
    [Serializable]
    public sealed class PixelFlowProgress : SaveData
    {
        public const string Key = "pixel-flow-progress";
        public override string SaveKey => Key;
        public int UnlockedLevel;
        public bool SoundEnabled = true;
        public List<int> CompletedLevels = new();
        public override void OnAfterLoad()
        {
            UnlockedLevel = Math.Max(0, UnlockedLevel);
            CompletedLevels ??= new List<int>();
        }
    }

    // Persistent progression is independent of the mutable puzzle session and its views.
    public sealed class ProgressStore
    {
        private readonly IDatasaveService service;
        private readonly int levelCount;
        public PixelFlowProgress Data { get; }
        public ProgressStore(IDatasaveService service, int levelCount)
        {
            this.service = service; this.levelCount = levelCount;
            Data = service.Load<PixelFlowProgress>(PixelFlowProgress.Key);
            Data.UnlockedLevel = Math.Clamp(Data.UnlockedLevel, 0, levelCount - 1);
        }
        public void Complete(int level)
        {
            if (level < 0 || level >= levelCount) throw new ArgumentOutOfRangeException(nameof(level));
            if (!Data.CompletedLevels.Contains(level)) Data.CompletedLevels.Add(level);
            Data.UnlockedLevel = Math.Max(Data.UnlockedLevel, Math.Min(level + 1, levelCount - 1));
            Save();
        }
        public void ToggleSound() { Data.SoundEnabled = !Data.SoundEnabled; Save(); }
        public void Save() => service.Save(Data);
    }
}
