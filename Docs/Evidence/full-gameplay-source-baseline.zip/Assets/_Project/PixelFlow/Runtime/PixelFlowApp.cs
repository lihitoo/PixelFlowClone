using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using Dreamy.DataConfig;
using Dreamy.Datasave;
using PixelFlow.Rules;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.UI;

namespace PixelFlow
{
    public enum AppScreen { Loading, Home, Playing, Paused, Won, Lost, Error }

    [DefaultExecutionOrder(-500)]
    public sealed class PixelFlowApp : MonoBehaviour
    {
        [SerializeField] private PixelFlowPresentation presentation;
        [SerializeField] private Camera worldCamera;
        private CancellationTokenSource lifetime;
        private DataConfigService configs;
        private ProgressStore progress;
        private DatasaveService saves;
        private PixelFlowView view;
        private BoardPresenter board;
        private AudioSource[] voices;
        private int voiceIndex;
        private float lastPop = -100, resultAt;
        private string initializationError;
        private int requestedExitCode;
        public PixelFlowCampaignConfig Campaign { get; private set; }
        public PuzzleSession Session { get; private set; }
        public AppScreen ScreenState { get; private set; } = AppScreen.Loading;
        public int SelectedLevel { get; private set; }
        public PixelFlowView View => view;
        public BoardPresenter Board => board;
        public ProgressStore Progress => progress;
        public Camera WorldCamera => worldCamera;
        public string SaveDirectory { get; private set; } = "PixelFlowCloneSaves";

        private void Awake()
        {
            if (HasCommandLine("-pixelFlowSmoke")) Application.runInBackground = true;
#if UNITY_STANDALONE_WIN && !UNITY_EDITOR
            if (Application.unityVersion == "6000.4.12f1") Application.wantsToQuit += ExitWindowsCompatibility;
#endif
        }

        public void RequestExit(int code = 0) { requestedExitCode = code; Application.Quit(code); }
#if UNITY_STANDALONE_WIN && !UNITY_EDITOR
        [System.Runtime.InteropServices.DllImport("kernel32.dll", EntryPoint = "GetCurrentProcess")]
        private static extern IntPtr CurrentProcessHandle();
        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool TerminateProcess(IntPtr handle, uint code);
#endif
        private bool ExitWindowsCompatibility()
        {
            // The matching native player faults in PlatformAccessibilityManager's
            // static teardown, even on an otherwise idle Home window. Flush this
            // scene owner's synchronous save, then end this process through Windows.
            // Review this version-scoped path before adding services with shutdown work.
            try { progress?.Save(); }
            catch (Exception error)
            {
                Debug.LogException(error, this); view?.Toast("Progress could not be saved. Please try closing again."); return false;
            }
            Debug.Log("[PixelFlow] Progress flushed; native Windows compatibility process exit.");
#if UNITY_STANDALONE_WIN && !UNITY_EDITOR
            if (!TerminateProcess(CurrentProcessHandle(), unchecked((uint)requestedExitCode)))
                Debug.LogError("Could not terminate the owned Windows player: " + System.Runtime.InteropServices.Marshal.GetLastWin32Error());
#endif
            return false;
        }

        private void Start()
        {
            Application.targetFrameRate = 60; QualitySettings.vSyncCount = 0;
            lifetime = new CancellationTokenSource();
            InitializeAsync(lifetime.Token).Forget();
        }

        private async UniTask InitializeAsync(CancellationToken token)
        {
            try
            {
                if (presentation == null || worldCamera == null || presentation.PigMesh == null || presentation.Font == null || presentation.LitMaterial == null)
                    throw new InvalidOperationException("Pixel Flow scene has incomplete presentation references.");
                if (FindAnyObjectByType<EventSystem>() == null)
                {
                    var events = new GameObject("EventSystem", typeof(EventSystem), typeof(InputSystemUIInputModule));
                    events.transform.SetParent(transform, false);
                    events.GetComponent<InputSystemUIInputModule>().AssignDefaultActions();
                }
                if (worldCamera.GetComponent<PhysicsRaycaster>() == null) worldCamera.gameObject.AddComponent<PhysicsRaycaster>();
                string scope = CommandLineValue("-pixelFlowSaveScope");
#if UNITY_EDITOR
                // Editor fixtures use an isolated save without adding a player option
                // or referencing Editor assemblies from this runtime assembly.
                scope ??= Environment.GetEnvironmentVariable("PIXEL_FLOW_EDITOR_SAVE_SCOPE");
#endif
                if (scope != null)
                {
                    if (scope.Length > 64 || !System.Text.RegularExpressions.Regex.IsMatch(scope, "^[A-Za-z0-9_-]+$"))
                        throw new ArgumentException("Invalid isolated save scope.");
                    SaveDirectory = "PixelFlowCloneSmoke_" + scope;
                }
                configs = new DataConfigService(new ResourcesJsonConfigSource("PixelFlow"));
                configs.Register<PixelFlowCampaignConfig>("pixelFlowCampaign");
                await configs.InitializeAsync(token);
                token.ThrowIfCancellationRequested();
                Campaign = configs.GetTable<PixelFlowCampaignConfig>();
                saves = new DatasaveService(new DatasaveOptions { DirectoryName = SaveDirectory, PrettyPrint = true });
                progress = new ProgressStore(saves, Campaign.Levels.Count);
                SelectedLevel = progress.Data.UnlockedLevel;
                view = new PixelFlowView(transform, presentation, Campaign.Levels.Count);
                view.PlayRequested += PlaySelected;
                view.PauseRequested += Pause;
                view.ResumeRequested += Resume;
                view.RestartRequested += Restart;
                view.MenuRequested += Home;
                view.NextRequested += Next;
                view.SoundRequested += ToggleSound;
                view.LevelSelected += SelectLevel;
                voices = new AudioSource[8];
                for (int i = 0; i < voices.Length; i++)
                {
                    var voice = new GameObject("SFX Voice " + i); voice.transform.SetParent(transform, false);
                    voices[i] = voice.AddComponent<AudioSource>(); voices[i].playOnAwake = false; voices[i].spatialBlend = 0;
                }
                Home();
#if UNITY_EDITOR || DEVELOPMENT_BUILD || PIXEL_FLOW_VERIFICATION
                if (HasCommandLine("-pixelFlowSmoke")) gameObject.AddComponent<PixelFlowSmoke>().Initialize(this);
#endif
            }
            catch (OperationCanceledException) when (token.IsCancellationRequested) { }
            catch (Exception error)
            {
                initializationError = "The game could not start. Existing progress has been kept.";
                ScreenState = AppScreen.Error;
                Debug.LogException(error, this);
            }
        }

        public static bool HasCommandLine(string name) => Array.IndexOf(Environment.GetCommandLineArgs(), name) >= 0;
        public static string CommandLineValue(string name)
        {
            string[] args = Environment.GetCommandLineArgs(); int index = Array.IndexOf(args, name);
            return index >= 0 && index + 1 < args.Length ? args[index + 1] : null;
        }

        private void SelectLevel(int index)
        {
            if (ScreenState != AppScreen.Home || index < 0 || index > progress.Data.UnlockedLevel) return;
            SelectedLevel = index; Play(presentation.Tap); view.ShowHome(progress.Data, index);
        }
        private void PlaySelected() => StartLevel(SelectedLevel);
        private void StartLevel(int index)
        {
            if (Campaign == null || index < 0 || index >= Campaign.Levels.Count || index > progress.Data.UnlockedLevel) return;
            ClearSession(); SelectedLevel = index;
            Session = new PuzzleSession(Campaign.Levels[index], Campaign.LoopSeconds, Campaign.ShotInterval);
            Session.Finished += OnFinished;
            board = new BoardPresenter(transform, worldCamera, presentation, Campaign, Session, Launch, PlayPop);
            resultAt = -1; ScreenState = AppScreen.Playing; view.ShowGame(index); Play(presentation.Tap);
            view.UpdateGame(Session, worldCamera);
        }

        private void Launch(int shooterId)
        {
            if (ScreenState != AppScreen.Playing || Session == null) return;
            switch (Session.Launch(shooterId))
            {
                case LaunchResult.Accepted: Play(presentation.Launch, .50f); break;
                case LaunchResult.ConveyorFull: view.Toast("Conveyor full! Wait for a pig to finish."); Play(presentation.Tap, .3f); break;
                case LaunchResult.Unavailable: view.Toast("Choose a pig at the front of a queue."); break;
            }
        }
        private void Pause()
        {
            if (ScreenState != AppScreen.Playing || Session?.Status != SessionStatus.Playing) return;
            ScreenState = AppScreen.Paused; view.ShowPause(progress.Data.SoundEnabled); Play(presentation.Tap);
        }
        private void Resume()
        {
            if (ScreenState != AppScreen.Paused) return;
            ScreenState = AppScreen.Playing; view.ShowGame(SelectedLevel); Play(presentation.Tap);
        }
        private void Restart()
        {
            if (ScreenState is AppScreen.Loading or AppScreen.Home or AppScreen.Error) return;
            StartLevel(SelectedLevel);
        }
        private void Home()
        {
            ClearSession(); ScreenState = AppScreen.Home;
            view.ShowHome(progress.Data, SelectedLevel);
        }
        private void Next()
        {
            if (ScreenState != AppScreen.Won) return;
            if (SelectedLevel + 1 >= Campaign.Levels.Count) Home(); else StartLevel(SelectedLevel + 1);
        }
        private void ToggleSound()
        {
            try { progress.ToggleSound(); }
            catch (Exception error) { Debug.LogException(error, this); view.Toast("Sound changed; progress could not be saved."); }
            view.UpdateSound(progress.Data.SoundEnabled);
            if (!progress.Data.SoundEnabled) foreach (var voice in voices) voice.Stop();
            else Play(presentation.Tap);
        }

        private void OnFinished(SessionStatus status)
        {
            resultAt = Time.unscaledTime + .55f;
            if (status == SessionStatus.Won)
            {
                try { progress.Complete(SelectedLevel); }
                catch (Exception error) { Debug.LogException(error, this); view.Toast("Level clear! Progress could not be saved."); }
                Play(presentation.Win, .65f);
            }
        }

        private void Update()
        {
            if (worldCamera != null) worldCamera.orthographicSize = Mathf.Max(8.4f, 4.55f / worldCamera.aspect);
            view?.Tick();
            if (Keyboard.current?.escapeKey.wasPressedThisFrame == true)
            {
                if (ScreenState == AppScreen.Playing) Pause(); else if (ScreenState == AppScreen.Paused) Resume();
            }
            if (Session == null) return;
            if (ScreenState == AppScreen.Playing) Session.Tick(Time.deltaTime);
            board?.Render(ScreenState == AppScreen.Paused ? 0 : Time.deltaTime);
            view.UpdateGame(Session, worldCamera);
            if (ScreenState == AppScreen.Playing && Session.Status != SessionStatus.Playing && resultAt >= 0 && Time.unscaledTime >= resultAt)
            {
                ScreenState = Session.Status == SessionStatus.Won ? AppScreen.Won : AppScreen.Lost;
                view.ShowResult(ScreenState == AppScreen.Won, SelectedLevel == Campaign.Levels.Count - 1, Session.Launches, Session.LossReason, progress.Data.SoundEnabled);
            }
        }

        private void PlayPop()
        {
            if (Time.unscaledTime - lastPop < .045f) return;
            lastPop = Time.unscaledTime; Play(presentation.Pop, .35f);
        }
        private void Play(AudioClip clip, float volume = .55f)
        {
            if (clip == null || voices == null || !progress.Data.SoundEnabled) return;
            var voice = voices[voiceIndex++ % voices.Length]; voice.Stop(); voice.clip = clip; voice.volume = volume; voice.Play();
        }
        private void ClearSession()
        {
            if (Session != null) Session.Finished -= OnFinished;
            board?.Dispose(); board = null; Session = null;
            if (voices != null) foreach (var voice in voices) voice.Stop();
            lastPop = -100; resultAt = -1;
        }
        private void SaveProgress()
        {
            try { progress?.Save(); }
            catch (Exception error) { Debug.LogException(error, this); }
        }
        private void OnApplicationPause(bool paused) { if (paused) { Pause(); SaveProgress(); } }
        private void OnApplicationQuit() => SaveProgress();
        private void OnDestroy()
        {
            Application.wantsToQuit -= ExitWindowsCompatibility;
            lifetime?.Cancel(); ClearSession(); view?.Dispose(); lifetime?.Dispose(); lifetime = null;
        }
        private void OnGUI()
        {
            if (initializationError == null) return;
            GUI.Box(new Rect(20, 20, UnityEngine.Screen.width - 40, 100), initializationError);
        }
    }
}
